// 'use strict';
// const defaultMenuWork26 = $('#Menu').find('li[data-work="26"]');
// const tabletMenuWork26 = $('#Menu--tablet').find('li[data-work="26"]');
//
// defaultMenuWork26.on('click', renderHW_26);
// tabletMenuWork26.on('click', renderHW_26);
//
// function renderHW_26 (e) {
//   const task = e.target.closest('li.Menu-item');
//   let taskNumber;
//
//   // Validate item link
//   if (task.classList.contains('disabled') || task.parentElement.classList.contains('Menu')) {
//     return;
//   }
//
//   taskNumber = parseInt(task.dataset.task);
//
//   switch (taskNumber) {
//     case 1:
//       HW_18.task1.render();
//       break;
//
//     default:
//       alert('This task doesn\'t exist :(');
//   }
// }
//
// class EventEmitter {
//   constructor () {
//     this._events = {}
//   }
//
//   // Add custom event and his function listener
//   // event - string, listener - function
//   on (event, listener) {
//     (this._events[event] || (this._events[event] = [])).push(listener);
//   }
//
//   // Run custom event
//   // event - string, args - array
//   emit (event, args) {
//     if (!this._events[event]) {
//       throw new Error('Emitter error, called event hasn\'t registered handlers');
//     }
//
//     this._events[event].forEach(listener => listener(args));
//   }
// }
//
// class StudentsModel extends EventEmitter {
//   constructor (students) {
//     super();
//     this._students = students || [];
//   }
//
//   getStudents () {
//     return this._students;
//   }
//
//   addStudent (student) {
//     this._students.unshift(student);
//     this.emit('studentAdded', student)
//   }
//
// }
//
// class StudentsView extends EventEmitter() {
//   constructor (model) {
//     super();
//     this._model = model;
//     this._elements = {};
//     this.constructor.createAddForm();
//     this.constructor.createTable();
//
//     // Attach model listeners
//
//     model.on('itemAdded', this.rebuildTable());
//     model.on('itemRemoved', this.rebuildTable());
//
//     this._elements.form.on('submit',
//         (e) => this.emit('newStudentSend', $(this).serializeArray()));
//   }
//
//   static createAddForm () {
//     this._elements.form = $(document.createElement('form'), {
//       method: 'POST',
//       class: 'Task-addStudentForm'
//     });
//     const nameInput = $(document.createElement('input'), {
//       type: 'text',
//       name: 'name',
//       placeholder: 'Enter your first and last name'
//     }).appendTo(this._elements.form);
//     const ageInput = $(document.createElement('input'), {
//       type: 'number',
//       name: 'age',
//       placeholder: 'Enter your age'
//     }).appendTo(this._elements.form);
//     const specInput = $(document.createElement('input'), {
//       type: 'text',
//       name: 'specialization',
//       placeholder: 'Enter your specialization'
//     }).appendTo(this._elements.form);
//     const yearInput = $(document.createElement('input'), {
//       type: 'number',
//       name: 'year',
//       placeholder: 'Enter your university year'
//     }).appendTo(this._elements.form);
//     const websiteInput = $(document.createElement('input'), {
//       type: 'text',
//       name: 'website',
//       placeholder: 'Enter your website'
//     }).appendTo(this._elements.form);
//     const phoneInput = $(document.createElement('input'), {
//       type: 'text',
//       name: 'phone',
//       placeholder: 'Enter your phone'
//     }).appendTo(this._elements.form);
//     const submitInput = $(document.createElement('input'), {
//       type: 'submit',
//       value: 'Add',
//     }).appendTo(this._elements.form);
//   }
//
//   static createTable () {
//     const table = $('<table>', {
//       class: 'Task-table'
//     });
//     const thead = $(document.createElement('thead')).appendTo(table);
//     this._list = $(document.createElement('tbody')).appendTo(table);
//     const tr = $(document.createElement('tr')).appendTo(thead);
//     const options = ['Select', 'Index', 'Name', 'Age', 'Specialization', 'Year of university', 'Website', 'Phone', 'Edit', 'Delete'];
//     let th;
//
//     options.forEach(option => {
//       th = $(document.createElement('th'), {text: option}).appendTo(tr);
//     })
//   }
//
//   createStudentTR (studentObj) {
//     const tr = $(document.createElement('tr'));
//     let td;
//     let key;
//
//     for (key in studentObj) {
//       if (studentObj.hasOwnProperty(key)) {
//         td = $(document.createElement('td'), {text: studentObj[key], 'data-column': key}).appendTo(tr);
//       }
//     }
//
//     return tr;
//   }
//
//   rebuildTable () {
//
//   }
// }
//
// class StudentController {
//   constructor (model, view) {
//     this._model = model;
//     this._view = view;
//
//     view.on('newStudentSend', this.addStudent);
//
//     model.on('studentAdded', this.)
//   }
//
//   addStudent (serializedData) {
//     const studentObj = this.constructor.parseData(serializedData);
//     this._model.addStudent(studentObj);
//   }
//
//   static parseData (data) {
//     const studentObj = {};
//     let i;
//     let key;
//     let value;
//
//     for (i = 0; i < data.length; i++) {
//       key = data[i].name;
//       value = data[i].value;
//
//       if (key === '' || value === '') {
//         throw new Error('Controller Error: failure during data parse ')
//       }
//
//       studentObj[key] = value;
//     }
//
//     return studentObj;
//   }
// }
